Run "python 17.py n > output.txt" Command

where n is the number of blocks you want to give. Then, you will get a output.txt file in that all the output