You can run the file by using the following command:

python 17.py input.txt

where input.txt contain the entire input as well as it is in the same folder as 17.py make sure to use python version 3+. After running the command the output will be shown in the terminal.